let playerX;
let playerY;
let playerWidth = 60;
let playerHeight = 80;

let favors = [];
let favorSpeed = 3;
let favorSize = 30;

let obstacles = [];
let obstacleSpeed = 2;
let obstacleSize = 40;

let score = 0;
let lives = 3;

let gameState = "start"; // "start", "playing", "gameOver"

function setup() {
  createCanvas(800, 600);
  playerX = width / 2; // Começa no meio
  playerY = height * 0.7 - playerHeight / 2; // No chão
  rectMode(CENTER); // Desenha retângulos a partir do centro
  imageMode(CENTER); // Se usar imagens, desenha a partir do centro
}

function draw() {
  if (gameState === "start") {
    displayStartScreen();
  } else if (gameState === "playing") {
    playGame();
  } else if (gameState === "gameOver") {
    displayGameOverScreen();
  }
}

function displayStartScreen() {
  background(135, 206, 235); // Céu azul claro
  fill(124, 252, 0); // Grama verde
  rect(width / 2, height * 0.85, width, height * 0.3); // Chão

  fill(0);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Corrida da Festa no Campo!", width / 2, height / 2 - 50);
  textSize(24);
  text("Apanhe os brindes, evite a lama!", width / 2, height / 2);
  text("Pressione ESPAÇO para Começar", width / 2, height / 2 + 50);
}

function playGame() {
  // Cenário
  background(135, 206, 235); // Céu azul claro
  fill(124, 252, 0); // Grama verde
  rect(width / 2, height * 0.85, width, height * 0.3); // Chão

  // Jogador
  fill(255, 100, 100); // Personagem vermelho
  rect(playerX, playerY, playerWidth, playerHeight);

  // Movimento do jogador
  if (keyIsDown(LEFT_ARROW)) {
    playerX -= 5;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    playerX += 5;
  }

  // Manter o jogador dentro dos limites
  playerX = constrain(playerX, playerWidth / 2, width - playerWidth / 2);

  // Brindes
  if (frameCount % 60 === 0) { // A cada segundo (60 quadros por segundo)
    favors.push(new Favor());
  }

  for (let i = favors.length - 1; i >= 0; i--) {
    favors[i].display();
    favors[i].move();

    // Verifica colisão com o jogador
    if (dist(playerX, playerY, favors[i].x, favors[i].y) < playerWidth / 2 + favorSize / 2) {
      score++;
      favors.splice(i, 1); // Remove o brinde apanhado
    } else if (favors[i].y > height) {
      favors.splice(i, 1); // Remove brindes que saem da tela
    }
  }

  // Obstáculos
  if (frameCount % 120 === 0) { // A cada 2 segundos
    obstacles.push(new Obstacle());
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].display();
    obstacles[i].move();

    // Verifica colisão com o jogador
    if (dist(playerX, playerY, obstacles[i].x, obstacles[i].y) < playerWidth / 2 + obstacleSize / 2) {
      lives--;
      obstacles.splice(i, 1); // Remove o obstáculo atingido
      if (lives <= 0) {
        gameState = "gameOver";
      }
    } else if (obstacles[i].y > height) {
      obstacles.splice(i, 1);
    }
  }

  // Exibe a pontuação
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Pontuação: " + score, 10, 10);

  // Exibe as vidas
  text("Vidas: " + lives, 10, 40);
}

function displayGameOverScreen() {
  background(255, 100, 100); // Fundo avermelhado
  fill(0);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("FIM DE JOGO!", width / 2, height / 2 - 50);
  textSize(32);
  text("Pontuação Final: " + score, width / 2, height / 2);
  text("Pressione R para Reiniciar", width / 2, height / 2 + 50);
}

function keyPressed() {
  if (gameState === "start" && keyCode === 32) { // Tecla ESPAÇO
    gameState = "playing";
    score = 0;
    lives = 3;
    favors = [];
    obstacles = [];
  } else if (gameState === "gameOver" && keyCode === 82) { // Tecla R
    gameState = "start";
    score = 0;
    lives = 3;
    favors = [];
    obstacles = [];
  }
}

class Favor {
  constructor() {
    this.x = random(width);
    this.y = 0; // Começa no topo
    this.type = floor(random(3)); // 0: balão, 1: chapéu, 2: cupcake
  }

  display() {
    push(); // Salva o estilo de desenho atual
    translate(this.x, this.y);
    noStroke();
    if (this.type === 0) {
      // Balão
      fill(255, 0, 0, 200); // Vermelho semi-transparente
      ellipse(0, 0, favorSize, favorSize * 1.2);
      stroke(0);
      line(0, favorSize * 0.6, 0, favorSize * 1.5);
    } else if (this.type === 1) {
      // Chapéu
      fill(0, 0, 255);
      triangle(0, -favorSize / 2, -favorSize / 2, favorSize / 2, favorSize / 2, favorSize / 2);
      rect(0, favorSize / 2 + 2.5, favorSize, 5); // Aba do chapéu
    } else {
      // Cupcake
      fill(255, 200, 100); // Cor do bolo
      ellipse(0, 0, favorSize, favorSize * 0.8);
      fill(100, 50, 0); // Cor da forminha
      rect(0, favorSize * 0.2 + 2.5, favorSize * 0.6, favorSize * 0.4);
      fill(255, 255, 255); // Cobertura
      ellipse(0, -favorSize * 0.3, favorSize * 0.7, favorSize * 0.4);
    }
    pop(); // Restaura o estilo de desenho
  }

  move() {
    this.y += favorSpeed;
  }
}

class Obstacle {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.type = floor(random(2)); // 0: lama, 1: inseto
  }

  display() {
    push();
    translate(this.x, this.y);
    noStroke();
    if (this.type === 0) {
      // Poça de lama
      fill(139, 69, 19, 200); // Marrom semi-transparente
      ellipse(0, 0, obstacleSize * 1.2, obstacleSize * 0.8);
    } else {
      // Inseto
      fill(50, 50, 50);
      ellipse(0, 0, obstacleSize * 0.8, obstacleSize * 0.6);
      fill(0);
      ellipse(-obstacleSize * 0.2, -obstacleSize * 0.2, 5, 5); // Olhos
      ellipse(obstacleSize * 0.2, -obstacleSize * 0.2, 5, 5);
      stroke(50, 50, 50);
      strokeWeight(2);
      line(-obstacleSize * 0.4, 0, -obstacleSize * 0.6, -obstacleSize * 0.2); // Pernas
      line(obstacleSize * 0.4, 0, obstacleSize * 0.6, -obstacleSize * 0.2);
    }
    pop();
  }

  move() {
    this.y += obstacleSpeed;
  }
}
